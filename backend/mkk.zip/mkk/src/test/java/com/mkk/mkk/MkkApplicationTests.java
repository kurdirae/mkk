package com.mkk.mkk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MkkApplicationTests {

	@Test
	void contextLoads() {
	}

}
